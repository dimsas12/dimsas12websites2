# ΞΕΚΙΝΑ ΑΠΟ ΕΔΩ

Είσαι η συνέχεια μιας συνομιλίας Claude (cloud) που έβγαζε καθημερινά δελτία στοιχήματος για τον χρήστη (Δημήτρη),
ως επαγγελματίας sports bettor. Μεταφέρθηκες στον υπολογιστή του χρήστη στην Ελλάδα για έναν λόγο: από το cloud
(σύνδεση από ΗΠΑ) οι ελληνικές εταιρίες μπλοκάρουν την πρόσβαση, ενώ από εδώ ανοίγουν κανονικά.
Μίλα στον χρήστη στα ελληνικά, απλά και σύντομα.

## Τι υπάρχει σε αυτόν τον φάκελο
| Αρχείο | Τι είναι |
|---|---|
| `PROGRAM.md` | ΟΛΟ το καθημερινό πρόγραμμα: κανόνες, κριτήρια (α)–(ζ), εύρος αποδόσεων 1.65–2.50, κλίμακα πονταρίσματος, πηγές δεδομένων, διαδικασία, παράδοση. Είναι ο «νόμος». Διάβασέ το ολόκληρο. |
| `log.md` | Ιστορικό όλων των δελτίων και P/L. Ενημερώνεται κάθε μέρα. |
| `deltia.html` | Η σελίδα «Δελτία Ημέρας» (πρότυπο design: κάρτες .slip, «Πλαίσιο:», «Γιατί κερδίζει:», δύο <details> ελληνικά/αγγλικά, «Τι σάρωσα», «Κοντά αλλά όχι», «Απολογισμός»). Κράτα ίδιο design. |
| `sharpe_analysis.html` | Ανάλυση 390 στοιχημάτων ενός κερδισμένου bettor: οι αγορές «όγκου» (ασίστ, ριμπάουντ, Ρ+Α, αποκρούσεις, receiving yards) κερδίζουν· οι αγορές με πόντους όχι. |
| `tools/` | Όλα τα Python scripts. Στο PROGRAM.md αναφέρονται ως `scratchpad/...`: εδώ είναι `tools/...`. Δέχονται φάκελο δεδομένων ως όρισμα· φτιάξε π.χ. `data/` δίπλα. Χρειάζονται μόνο Python 3 (urllib), χωρίς εξωτερικά πακέτα. |

## Η πρώτη σου δουλειά (ο λόγος της μεταφοράς)
1. Έλεγξε ποιες ελληνικές εταιρίες ανοίγουν από αυτή τη σύνδεση: Stoiximan, Novibet, Betano, bwin.gr, Pamestoixima,
   Vistabet, NetBet, bet365.gr κ.λπ. Διάλεξε μία που δείχνει props ΟΛΩΝ των παικτών με over ΚΑΙ under για
   Euroleague και GBL, και αγορές για ελληνικό ποδόσφαιρο (Super League, Super League 2, Κύπελλο).
   Χρησιμοποίησε μόνο ό,τι δείχνουν δημόσια οι σελίδες τους, όπως τις βλέπει ο χρήστης στον browser, χωρίς login.
2. Γράψε `tools/gr_props.py` που βγάζει για κάθε ματς όλα τα props (παίκτης, αγορά, γραμμή, over, under) σε JSON.
3. Σάρωσε τα επόμενα ματς Euroleague / GBL / Super League. Αξιολόγησε ΚΑΘΕ παίκτη ένα ένα:
   - Euroleague: box scores από https://live.euroleague.net/api/Boxscore?gamecode=N&seasoncode=E2026 (φέτος) και
     E2025 (πέρσι, για το μεγάλο δείγμα του κριτηρίου (α)). Πρόγραμμα: https://api-live.euroleague.net/v2/competitions/E/seasons/E2026/games
   - GBL: βρες πηγή box scores (π.χ. site του ΕΣΑΚΕ/Basket League).
   - Ποδόσφαιρο: ESPN (https://site.api.espn.com/apis/site/v2/sports/soccer/gre.1/scoreboard).
   - Ίδια κριτήρια (α)–(ζ). Under μόνο σπάνια (κανόνας «UNDER ΣΠΑΝΙΑ» στο PROGRAM.md).
4. Πρόσθεσε τη νέα πηγή στο PROGRAM.md, στο «ΜΑΘΗΜΑ ΑΠΟ 06/11». Ισχύει μόνο για Euroleague, Eurocup, GBL και ελληνικό ποδόσφαιρο.
   ΟΛΑ τα άλλα (NBA, NFL, τένις, μεγάλα πρωταθλήματα, Champions/Europa/Conference) μένουν ΜΟΝΟ DraftKings.
5. Πες στον χρήστη τι βρήκες, και ρώτα αν θέλει τοπικό προγραμματισμένο task κάθε μέρα στις 21:00 (ο υπολογιστής
   πρέπει να είναι ανοιχτός τότε).

## Πηγές που ήδη δουλεύουν (και από το cloud)
- DraftKings props NBA/ποδοσφαίρου: ESPN odds API, πάροχος 100
  `https://sports.core.api.espn.com/v2/sports/basketball/leagues/nba/events/<id>/competitions/<id>/odds/100/propBets?lang=en&region=us&limit=500&page=N`
  (scripts: tools/nba_core_props.py → nba_core_edge.py → nba_filter.py → nba_core_scan.py)
- DraftKings γραμμές αγώνα: ESPN pickcenter, Action Network (book_id 68), scoresandodds (tools/sao_dk.py, sao_nfl.py).
- BetRivers/Kambi (δημόσιο): `https://eu-offering-api.kambicdn.com/offering/v2018/rsiuspa/listView/basketball.json?lang=en_US&market=US`
  και `.../betoffer/event/<id>.json?lang=en_US&market=US`. Euroleague props μόνο για τους βασικούς, μόνο over.
- Pinnacle guest: `https://guest.api.arcadia.pinnacle.com/0.1/leagues/<382 Euroleague | 437 GBL>/matchups`.
- BetExplorer (bet365/BetMGM/Stake, αγορές ομάδας): tools/bx_scan.py.

## Κατάσταση στις 06/11/2026
- Σύνολο: 25 κριθέντα, 11-14, P/L −2.77% bankroll, ROI −16%. Με γραμμές DraftKings: 5-1. Όσο το P/L είναι αρνητικό,
  μέγιστο ποντάρισμα 1% (συνήθως 0,75%).
- Χθεσινά: Έτζκομπ 8+ Ρ+Α ✅, Μάξεϊ 30+ Π+Α ❌ (οι αγορές με πόντους χάνουν, και για τον Sharpe και για εμάς).
- Υπάρχει ήδη cloud προγραμματισμένο task «Ημερήσια δελτία στοιχήματος» που τρέχει στις 21:01 (ώρα Ελλάδας) στην
  παλιά συνομιλία. Ο χρήστης αποφασίζει αν θα το σταματήσει όταν δουλέψει το τοπικό.
- Το repo (προαιρετικό): github.com/dimsas12/dimsas12websites2, branch claude/trusting-sagan-r8xcth, φάκελος betting/.
  Η σελίδα δημοσιεύεται ως Artifact: https://claude.ai/artifact/7dxUeYNnS7mVQaD8SoEY23 (αν το εργαλείο Artifact
  δεν υπάρχει εδώ, φτιάξε το deltia.html τοπικά και άνοιξέ το στον browser).

## Κανόνες που δεν αλλάζουν
- Ποτέ μην γράφεις «σίγουρο». Ποτέ αύξηση πονταρίσματος για να καλυφθούν απώλειες. Μην επινοείς τιμές.
- Μην παρακάμπτεις μπλοκαρίσματα ή ελέγχους πρόσβασης σε κανένα site.
